if (typeof JSON.decycle !== 'function') {
    (function () {
        function stringifyNode(node) {
            var text = "";
            switch (node.nodeType) {
                case node.ELEMENT_NODE:
                    text = node.nodeName.toLowerCase();
                    if (node.id.length) {
                        text += '#' + node.id;
                    }
                    else {
                        if (node.className.length) {
                            text += '.' + node.className.replace(/ /, '.');
                        }
                        if ('textContent' in node) {
                            text += '{textContent:' + (node.textContent.length < 20 ? node.textContent : node.textContent.substr(0, 20) + '...') + '}';
                        }
                    }
                    break;
                default:
                    text = node.nodeName;
                    if (node.nodeValue !== null) {
                        text += '{value:' + (node.nodeValue.length < 20 ? node.nodeValue : node.nodeValue.substr(0, 20) + '...') + '}';
                    }
                    break;
            }
            return text;
        }
        JSON.decycle = function decycle(object, stringifyNodes) {
            'use strict';
            var objects = [], stringifyNodes = typeof (stringifyNodes) === 'undefined' ? false : stringifyNodes, paths = [];
            return (function derez(value, path) {
                var i, name, nu;
                if (stringifyNodes && typeof value === 'object' && value !== null && 'nodeType' in value) {
                    return stringifyNode(value);
                }
                if (typeof value === 'object' && value !== null && !(value instanceof Boolean) && !(value instanceof Date) && !(value instanceof Number) && !(value instanceof RegExp) && !(value instanceof String)) {
                    for (i = 0; i < objects.length; i += 1) {
                        if (objects[i] === value) {
                            return { $ref: paths[i] };
                        }
                    }
                    objects.push(value);
                    paths.push(path);
                    if (Object.prototype.toString.apply(value) === '[object Array]') {
                        nu = [];
                        for (i = 0; i < value.length; i += 1) {
                            nu[i] = derez(value[i], path + '[' + i + ']');
                        }
                    }
                    else {
                        nu = {};
                        for (name in value) {
                            if (Object.prototype.hasOwnProperty.call(value, name) || (value instanceof SVGMatrix && value["__proto__"].hasOwnProperty(name))) {
                                nu[name] = derez(value[name], path + '[' + JSON.stringify(name) + ']');
                            }
                        }
                    }
                    return nu;
                }
                return value;
            }(object, '$'));
        };
    })();
}
if (typeof JSON.retrocycle !== 'function') {
    JSON.retrocycle = function retrocycle($) {
        'use strict';
        var px = /^\$(?:\[(?:\d+|\"(?:[^\\\"\u0000-\u001f]|\\([\\\"\/bfnrt]|u[0-9a-zA-Z]{4}))*\")\])*$/;
        (function rez(value) {
            try {
                var i, item, name, path;
                if (value && typeof value === 'object') {
                    if (Object.prototype.toString.apply(value) === '[object Array]') {
                        for (i = 0; i < value.length; i += 1) {
                            item = value[i];
                            if (item && typeof item === 'object') {
                                path = item.$ref;
                                if (typeof path === 'string' && px.test(path)) {
                                    value[i] = eval(path);
                                }
                                else {
                                    rez(item);
                                }
                            }
                        }
                    }
                    else {
                        for (name in value) {
                            if (typeof value[name] === 'object') {
                                item = value[name];
                                if (item) {
                                    path = item.$ref;
                                    if (typeof path === 'string' && px.test(path)) {
                                        value[name] = eval(path);
                                    }
                                    else {
                                        rez(item);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (e) {
                Common.Logger.setErrLog(1007 /* json */, "文件:JsonDecycle,方法:rez,异常信息：" + e);
            }
        }($));
        return $;
    };
}
//# sourceMappingURL=JsonDecycle.js.map